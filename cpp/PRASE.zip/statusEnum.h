#ifndef STATUSENUM_H
#define STATUSENUM_H

enum StatusEnum {
    OK,
    INVALID
};

#endif  // STATUSENUM_H

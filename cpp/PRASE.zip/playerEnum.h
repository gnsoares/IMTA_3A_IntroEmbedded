#ifndef PLAYERENUM_H
#define PLAYERENUM_H

#include "config.h"

enum Player {
    NO_PLAYER,
    PLAYER_1,
    PLAYER_2
};

#endif  // PLAYERENUM_H
